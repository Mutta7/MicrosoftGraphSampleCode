Param(
    # microsoft graph reource url
    [Parameter(ValueFromPipeline = $true, Mandatory = $false)]
    [String]
    $resource = "https://graph.microsoft.com",
    # tenantId
    [Parameter(ValueFromPipeline = $true, Mandatory = $false)]
    [String]
    $tenantId = "<tenant id>",
    # clientId
    [Parameter(ValueFromPipeline = $true, Mandatory = $false)]
    [String]
    $clientId = "<app id>",
    # certificateThumbprint
    [Parameter(ValueFromPipeline = $true, Mandatory = $false)]
    [String]
    $thumbprint = "<certificate thumbprint>",
    # application Secret
    [Parameter(ValueFromPipeline = $true, Mandatory = $false)]
    [string]
    $clientSecret = ""

)

$scope = "$resource/.default"
$scopes = New-Object System.Collections.ObjectModel.Collection["string"]
$scopes.add($scope)

function Get-AccessToken () {
    if($null -eq $Local:confidentialApp) {
        Add-Type -Path "C:\Users\hsnzn\powershell\getUserInfo\Tools\Microsoft.Identity.Client\Microsoft.Identity.Client.dll"
        $cert = Get-ChildItem -path Cert:\CurrentUser\My | Where-Object {$_.Thumbprint -eq $thumbprint}

        $Local:confidentialApp = [Microsoft.Identity.Client.ConfidentialClientApplicationBuilder]::Create($clientId).WithCertificate($cert).withTenantId($tenantId).Build()
        #$local:confidentialApp = [Microsoft.Identity.Client.ConfidentialClientApplicationBuilder]::Create($clientId).WithClientSecret($clientSecret).withTenantId($tenantId).Build()
    }
    
    $authResult = $Local:confidentialApp.AcquireTokenForClient($scopes).ExecuteAsync().Result
    if($null -eq $authResult){
        Write-Host "ERROR: No Access Token"
        exit
    }
    return $authResult
}

function Get-AuthorizationHeader {
    $authResult = Get-AccessToken
    $accessToken = $authResult.AccessToken
    return @{'Authorization' = "Bearer $($accessToken)" }
    
}

$UPN = Read-Host "Input UPN "

$reqUrl = "$resource/v1.0/users/$($UPN)"

$headerParams = Get-AuthorizationHeader
$userInfoJson = (Invoke-WebRequest -UseBasicParsing -Headers $headerParams -Uri $reqUrl).Content | ConvertFrom-Json
$userId = $userInfoJson.id

$userId
$reqUrl = "$resource/v1.0/identityProtection/riskyUsers/$($userId)"
$userRisk = (Invoke-WebRequest -UseBasicParsing -Headers $headerParams -Uri $reqUrl).Content | ConvertFrom-Json

$userRisk

if($userRisk.riskLevel -match "high"){
    Write-host "risk level is high."
    $reqUrl_dismisss = "$resource/v1.0/identityProtection/riskyUsers/dismiss"
    $reqbody = @{
        'userIds'= @(
            "$userId")     
    }
    $reqBody
    $dismissRiskResponse = Invoke-RestMethod -UseBasicParsing -Headers $headerParams -Body ($reqBody | ConvertTo-Json) -Uri $reqUrl_dismisss -Method POST -ContentType "application/json" -Verbose
    $dismissRiskResponse
}else{
    Write-Host "risk is not high."
}


